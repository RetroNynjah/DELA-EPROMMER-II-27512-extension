I translated the original DELA EPROMMER software from German to English, using Google translator.
Since english is not my native language, a better translation could be done.
I used HxD (https://mh-nexus.de/en/hxd/) to translate the software, but any hex editor can be used.


I hope it will be easier to use than the original german version (even with all the mistakes and poor translation). 


I also found an extended german manual; again, I used Google to translate it. I then extract some
quick informations from it (you can find both manuals in the Zip file).


NOTE 1: I tried to translate "EPROMMER II CR.PRG" but it refused to work (I must have done some
        mistakes), so I left the original german version. However it seems to be another version 
        of "EPROMMER II.PRG", so maybe there's no need for it. I will try to fix it later (maybe).

NOTE 2: I didn't translate yet "MEMCOM V 1.0.PRG"; it's an internal manual, but since it's not 
        directly related with eprom programming, I decided to leave it in german. Maybe I will 
        translate it in the future.

11/2022 - Giovi